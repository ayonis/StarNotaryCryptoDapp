var HDWalletProvider = require('@truffle/hdwallet-provider');
//
// const fs = require('fs');
//const mnemonic = fs.readFileSync(".secret").toString().trim();
const mnemonic = "spirit supply whale amount human item harsh scare congress discover talent hamster";
module.exports = {
  networks: {    
    rinkeby: {                                
      provider: function() { 
        return new HDWalletProvider(mnemonic, `https://rinkeby.infura.io/v3/7e6520f7db7f4e3aa371565a82010695`);
       },
       network_id: 4,
       gasPrice: 21000000000,
       skipDryRun: true
    },
  },
  // Set default mocha options here, use special reporters etc.
  mocha: {
    // timeout: 100000
  },
  // Configure your compilers
  compilers: {
    solc: {
      // version: "0.5.1",    // Fetch exact version from solc-bin (default: truffle's version)
      version: "0.6.2",
      // docker: true,        // Use "0.5.1" you've installed locally with docker (default: false)
      // settings: {          // See the solidity docs for advice about optimization and evmVersion
      //  optimizer: {
      //    enabled: false,
      //    runs: 200
      //  },
      //  evmVersion: "byzantium"
      // }
    }
  }
}
